﻿using ChatAppAPI.Models;

namespace ChatAppAPI.Repository
{
    public interface IMessageRepository : IChatApiRepository<Message>
    {
    }
}
