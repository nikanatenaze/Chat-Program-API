﻿using ChatAppAPI.Models;

namespace ChatAppAPI.Repository
{
    public interface IChatRepository : IChatApiRepository<Chat>
    {
    }
}
