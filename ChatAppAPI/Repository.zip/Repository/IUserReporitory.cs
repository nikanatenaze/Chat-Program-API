﻿using ChatAppAPI.Models;

namespace ChatAppAPI.Repository
{
    public interface IUserReporitory : IChatApiRepository<User>
    {
    }
}
